import React from "react";

const OurCours = () => {
  return <div>
    
  </div>;
};

export default OurCours;
