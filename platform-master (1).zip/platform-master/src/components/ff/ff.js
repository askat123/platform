import React from 'react';
import './ff.scss';


const Fflol = () => {
    return (
        <div id="ff">
           
        </div>
    );
};

export default Fflol;