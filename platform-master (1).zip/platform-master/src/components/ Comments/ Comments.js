import React from "react";
import "./ Comments.scss";

const Comments = () => {
  return (
    <div id="comments">
      <div className="comments">
        <h1>Коментарии</h1>
        <p>Вы еще не написали комментариев</p>
      </div>
    </div>
  );
};

export default Comments;
