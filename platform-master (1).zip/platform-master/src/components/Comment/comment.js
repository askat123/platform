import React from "react";

const comment = () => {
  return (
    <div className="App">
      <h1>Секция комментариев</h1>
      <CommentInput/>
    </div>
  );
};

export default comment;
